//
// Created by kezjo on 24-10-3.
//

#ifndef PREPROCESS_H
#define PREPROCESS_H
#include<opencv2/opencv.hpp>


class PreProcess {
public:
    cv::Mat Process(cv::Mat image,int Color);
};



#endif //PREPROCESS_H
